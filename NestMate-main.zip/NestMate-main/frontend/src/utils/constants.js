export const SHARING_OPTIONS = ["Single", "Double", "Triple", "Four+"];
export const GENDER_OPTIONS = ["Male", "Female", "Any"];
export const FOOD_OPTIONS = ["Veg", "Non-Veg", "Vegan", "Any"];
export const SLEEP_OPTIONS = ["Early Bird", "Night Owl", "Flexible"];
export const YES_NO = ["Yes", "No"];
export const CLEANLINESS_OPTIONS = ["Very Clean", "Moderate", "Doesn't Matter"];
export const PROPERTY_TYPES = ["Flat", "PG", "Hostel"];
export const AMENITY_OPTIONS = ["WiFi", "AC", "Washing Machine", "Refrigerator", "Study Table", "Parking", "Lift", "Power Backup", "RO Water", "Geyser"];
export const OCCUPATION_OPTIONS = ["Student", "Working Professional", "Any"];
export const FURNISHING_OPTIONS = ["Unfurnished", "Semi-furnished", "Fully-furnished"];
export const FOOD_AVAILABILITY_OPTIONS = ["Mess Included", "Self-Cooking", "Cook Available", "Not Available"];
export const SORT_OPTIONS = [
  { value: "latest", label: "Latest" },
  { value: "oldest", label: "Oldest" },
  { value: "rent_low", label: "Rent: Low to High" },
  { value: "rent_high", label: "Rent: High to Low" },
];
export const ITEMS_PER_PAGE = 12;
