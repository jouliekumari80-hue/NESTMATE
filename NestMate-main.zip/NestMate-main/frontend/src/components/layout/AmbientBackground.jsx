export default function AmbientBackground() {
  return (
    <>
      <div className="ambient-blob blob-primary" />
      <div className="ambient-blob blob-secondary" />
      <div className="ambient-blob blob-tertiary" />
      <div className="ambient-blob blob-bottom" />
    </>
  );
}
